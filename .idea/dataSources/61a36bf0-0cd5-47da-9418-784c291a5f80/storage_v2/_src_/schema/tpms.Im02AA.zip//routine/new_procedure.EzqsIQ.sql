create procedure new_procedure()
  BEGIN
	declare i int;
    
    set i=0;
    while i < 900 do
		INSERT INTO `tpms`.`ats_testtask_info` (`TaskID`, `TestImage`, `DMIModifyFlag`, `DMI_PartNumber`, `DMI_SerialNumer`, `DMI_OEMString`, `TestItem`, `TestMachine`, `MachineID`, `PowerID`, `LANID`, `LANIP`, `ShelfID`, `TestResult`, `TestResultPath`, `TestStartTime`, `TestEndTime`, `TaskStatus`, `Tester`)
		VALUES (NULL, 'TI10661700B', '1', 'PT24C', 'ZD102073H', 'PT24C--ZD', 'JumpStart', 'Altair TX20 CS2 SKU2', '1308044', '1', '1', '1', '1', 'pass', '192.168.10.43//test', '2009-06-08 23:53:17', '2009-06-08 23:53:17', '1', 'Xu.wanliang');

	end while;


END;

